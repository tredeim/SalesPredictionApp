﻿public class Sale
{
    public int ProductId { get; init; }
    public DateTime Date { get; init; }
    public int Sales { get; init; }
    public int Stock { get; init; }
}
