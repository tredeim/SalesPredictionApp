﻿public class SeasonCoef
{
    public int ProductId { get; init; }
    public int Month { get; init; }
    public double Coef { get; init; }
}